from flask import Flask, request, render_template_string
import os

CONF_PATH = "/opt/pirateradio/radio.conf"

TEMPLATE = """<!doctype html>
<html>
<head>
<title>Pirate Radio Config</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body { font-family: Arial, sans-serif; max-width: 600px; margin: 20px auto; padding: 0 10px; }
h2 { margin-bottom: 0.5em; }
label { display:block; margin-top: 10px; font-weight:bold; }
input[type=text] { width:100%; padding:6px; margin-top:4px; box-sizing:border-box; }
input[type=submit] { margin-top:12px; padding:8px 16px; cursor:pointer; }
.ok { color: green; font-weight:bold; margin-top:10px; }
.small { font-size:0.9em; color:#555; margin-top:15px; }
code { background:#eee; padding:2px 4px; border-radius:3px; }
</style>
</head>
<body>
<h2>Pirate Radio Configuration</h2>

{% if saved %}
  <p class="ok">Settings saved.</p>
{% endif %}

<form method="post">
  <label>Frequency (MHz)</label>
  <input type="text" name="freq" value="{{ freq }}">

  <label>Station Name (PS, 8 chars max)</label>
  <input type="text" name="ps" value="{{ ps }}">

  <label>Radio Text (RT)</label>
  <input type="text" name="rt" value="{{ rt }}">

  <label>Audio File Path (.wav)</label>
  <input type="text" name="audio" value="{{ audio }}">

  <input type="submit" value="Save Settings">
</form>

<p class="small">
After saving, restart the radio service:<br>
<code>sudo systemctl restart pirateradio.service</code>
</p>

</body>
</html>"""

app = Flask(__name__)

def load_conf():
    data = {"FREQ":"100.0","PS":"MYRADIO","RT":"Hello World","AUDIO":"/home/pi/music.wav"}
    if os.path.exists(CONF_PATH):
        with open(CONF_PATH) as f:
            for line in f:
                if "=" in line:
                    key, value = line.strip().split("=",1)
                    if value.startswith('"') and value.endswith('"'):
                        value = value[1:-1]
                    data[key]=value
    return data

def save_conf(c):
    with open(CONF_PATH,"w") as f:
        f.write(f'FREQ={c["FREQ"]}\n')
        f.write(f'PS="{c["PS"]}"\n')
        f.write(f'RT="{c["RT"]}"\n')
        f.write(f'AUDIO="{c["AUDIO"]}"\n')

@app.route("/",methods=["GET","POST"])
def index():
    saved=False
    conf=load_conf()

    if request.method=="POST":
        conf["FREQ"]=request.form.get("freq",conf["FREQ"]).strip() or "100.0"
        conf["PS"]=(request.form.get("ps",conf["PS"]).strip() or "MYRADIO")[:8]
        conf["RT"]=request.form.get("rt",conf["RT"]).strip()
        conf["AUDIO"]=request.form.get("audio",conf["AUDIO"]).strip()
        save_conf(conf)
        saved=True

    return render_template_string(TEMPLATE, saved=saved, **conf)

if __name__=="__main__":
    app.run(host="0.0.0.0", port=8080)
