#!/bin/bash
source /opt/pirateradio/radio.conf
while true; do
  /opt/pirateradio/PiFmRds/src/pi_fm_rds     -freq "$FREQ"     -audio "$AUDIO"     -ps "$PS"     -rt "$RT"
  sleep 1
done
